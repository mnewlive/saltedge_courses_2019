5.times do |index|
	 puts "hello #{index}"
	 end
	 

n = 1 
while n < 10
	puts n
	n += 1
end


n = 1 
while n < 10
	puts n 
	break if n == 5 
	n += 1
end




